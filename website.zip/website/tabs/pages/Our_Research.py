import requests 
import streamlit as st
from streamlit_lottie import st_lottie
from PIL import Image

st.set_page_config(page_title = "My webpage", page_icon = ":tada:", layout = "wide")
image_Graph2 = Image.open("Images/Graph5.jpg")
image_Graph3 = Image.open("Images/Graph6.jpg")
image_Graph4 = Image.open("Images/Graph7.jpg")


with st.container():
    st.subheader("Our Work!!")
    st.title("The Research We have Done")
    st.write("Using the wonder of Machine Learning, and regression in specific, we were able to research and plot accurate line graphs from data sets online!!!. We we were extremely curious about the devastating effects of Global Warming , so we found extremely accurate data to try and answer our questions, and to make it easier to understand , we plotted a line graph to better understand the effects")



with st.container():
    st.write("---")
    st.header("How much ice melts every year in Antartica??")
    st.write("##")
    image_column, text_column = st.columns((1, 2))
    with image_column:
         st.image(image_Graph2)
    with text_column:
        st.write("Using regression and a data set from online, we were able to plot a line of best fit for a graph, calculating the the mass of ice and antartica. From the line graph , it can vividly be seen from the negative gradient of the graph that more and more ice keeps melting each year in Antartica. This is a direct Result of GLobal Warming.") 


with st.container():
    st.write("---")
    st.header("What are the Values of N2000 every year")
    st.write("##")
    text_column, image_column = st.columns((2, 1))
    with image_column:
         st.image(image_Graph3)
    with text_column:
        st.write("The N2000 is the vertical coordinate reference system that is used to report ground and sea levels. It is the Finnish implementation of the common European Vertical Reference System, and it uses the Amsterdam zero level, or NAP (Normaal Amsterdams Peil), as its base level. From the negative gradient from the graph, it is clearly visible that the value of n2000 keeps decreasing every year, showing the rise in sea level every year.")

with st.container():
    st.write("---")
    st.header("How much Carbon Di-oxide is produced every year?")
    st.write("##")
    image_column, text_column = st.columns((1, 2))
    with image_column:
         st.image(image_Graph4)
    with text_column:
        st.write("AS we know, CO2 emmissions are a primary cuase of increasing global warming, so we looked up databses and plotted a linear grpah to get a birds eye view on the C02 production, and the positive graph confirms this. ")
        