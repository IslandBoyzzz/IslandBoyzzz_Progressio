import requests 
import streamlit as st
from streamlit_lottie import st_lottie
from PIL import Image

st.set_page_config(page_title = "GlobalWarming", page_icon = ":fire:", layout = "wide")

def load_lottieurl2(url):
    r = requests.get(url)
    if r.status_code != 200:
        return None
    return r.json()

    
lottie_animation = load_lottieurl2("https://assets3.lottiefiles.com/packages/lf20_qaemdbel.json")



with st.container():
    st.subheader("Global Warming ")
    st.title("What Exactly is it?")
    st.write("Global warming is the long-term warming of the planet’s overall temperature. Though this warming trend has been going on for a long time, its pace has significantly increased in the last hundred years due to the burning of fossil fuels. As the human population has increased, so has the volume of fossil fuels burned. Fossil fuels include coal, oil, and natural gas, and burning them causes what is known as the “greenhouse effect” in Earth’s atmosphere.")



with st.container():
    st.write("---")
    left_column, right_column = st.columns(2)
    with left_column:
        st.header("Global Warming - Explained")
        st.write("##")
        st.write("The greenhouse effect is when the Sun’s rays penetrate the atmosphere, but when that heat is reflected off the surface cannot escape back into space. Gases produced by the burning of fossil fuels prevent the heat from leaving the atmosphere. These greenhouse gasses are carbon dioxide, chlorofluorocarbons, water vapor, methane, and nitrous oxide. The excess heat in the atmosphere has caused the average global temperature to rise overtime, otherwise known as global warming. Global warming has presented another issue called climate change. Sometimes these phrases are used interchangeably, however, they are different. Climate change refers to changes in weather patterns and growing seasons around the world. It also refers to sea level rise caused by the expansion of warmer seas and melting ice sheets and glaciers. Global warming causes climate change, which poses a serious threat to life on earth in the forms of widespread flooding and extreme weather. Scientists continue to study global warming and its impact on Earth.")

    with right_column:
        st_lottie(lottie_animation, height = 300, key="climate change")


image_contact_form = Image.open("Images/Graph1.png")
image_oceans = Image.open("Images/Photo1.png")
image_acid = Image.open("Images/Acidification.png")

with st.container():
    st.write("---")
    st.header("Consequences Of Global Warming")
    st.write("##")
    image_column, text_column = st.columns((1, 2))
    with image_column:
         st.image(image_contact_form)
    with text_column:
        st.subheader(" Rising Temperature")
        st.write("One of the most immediate and obvious consequences of global warming is the increase in temperatures around the world. The average global temperature has increased by about 1.4 degrees Fahrenheit (0.8 degrees Celsius) over the past 100 years, according to the National Oceanic and Atmospheric Administration (NOAA).")
        


with st.container():
    st.write("---")
    st.header("Consequences Of Global Warming - Continued")
    st.write("##")
    text_column, image_column = st.columns((2,1))
    with image_column:
         st.image(image_oceans)
    with text_column:
        st.subheader(" More frequent and intense extreme weather events:")
        st.write("Extreme weather events like bushfires, cyclones, droughts and floods are becoming more frequent and more intense as a result of global warming.")
        


with st.container():
    st.write("---")
    st.header("Consequences Of Global Warming - Continued")
    st.write("##")
    image_column, text_column = st.columns((1, 2))
    with image_column:
         st.image(image_acid)
    with text_column:
        st.subheader(" Oceans are warming and acidifying:")
        st.write("The oceans have absorbed most of extra heat and carbon dioxide (CO2) so far – more than the air – making the seas both warmer and more acidic. Warming waters are bleaching coral reefs and driving stronger storms. Rising ocean acidity threatens shellfish, including the tiny crustaceans without which marine food chains would collapse.")
        













